"""競輪AI PRO: 公開CSVから出走表を同期する。データがなければ失敗を明示。"""
import csv
import io
import json
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

JST = timezone(timedelta(hours=9))
BASE = 'https://raw.githubusercontent.com/Kenseimk/keirin-data/main/keirin_data/'
OUT = Path(__file__).resolve().parent / 'keirin_data.json'

def get_rows(year, month):
    url = f'{BASE}{year}_{month:02d}_keirin.csv'
    req = urllib.request.Request(url, headers={'User-Agent': 'KeirinAIPro/1.1'})
    with urllib.request.urlopen(req, timeout=25) as resp:
        return list(csv.DictReader(io.StringIO(resp.read().decode('utf-8-sig'))))

def main():
    now = datetime.now(JST)
    first = now.replace(day=1)
    months = [(first - timedelta(days=1)).strftime('%Y-%m'), first.strftime('%Y-%m'), (first.replace(day=28) + timedelta(days=4)).strftime('%Y-%m')]
    races, errors = {}, []
    for ym in dict.fromkeys(months):
        y, m = map(int, ym.split('-'))
        try:
            rows = get_rows(y, m)
            print(ym, 'rows:', len(rows), 'columns:', list(rows[0]) if rows else [])
            for row in rows:
                date = (row.get('date') or '').strip()
                rid = (row.get('race_id') or '').strip()
                name = (row.get('player_name') or '').strip()
                if not (date and rid and name) or date < now.strftime('%Y-%m-%d'):
                    continue
                race = races.setdefault(rid, {'race_id': rid, 'date': date, 'venue': row.get('venue_slug') or row.get('venue') or '', 'race_no': row.get('race_no') or '', 'players': []})
                race['players'].append({'number': row.get('banum') or '', 'name': name, 'score': row.get('race_score') or '', 'style': row.get('running_style') or '', 'line': row.get('lineup') or '', 'class': row.get('player_class') or ''})
        except Exception as exc:
            errors.append(f'{ym}: {exc}')
            print('ERROR:', errors[-1])
    payload = {'updated_at': now.isoformat(), 'source': BASE, 'races': list(races.values()), 'predictions': [], 'results': [], 'errors': errors, 'status': '取得成功' if races else '出走表0件：取得元のCSV未公開・列名不一致・開催データなしの可能性'}
    if races:
        OUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
        print('Saved', len(races), 'races')
    else:
        print('No races: preserving existing file to avoid overwriting valid data')
        raise RuntimeError(payload['status'] + '; ' + '; '.join(errors))

if __name__ == '__main__':
    main()
